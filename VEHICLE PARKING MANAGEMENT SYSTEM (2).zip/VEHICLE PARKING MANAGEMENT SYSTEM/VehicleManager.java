import java.util.ArrayList;
import java.util.List;

public class VehicleManager {

    List<Vehicle> list = new ArrayList<>();

    public void addVehicle(Vehicle v) {
        list.add(v);
    }

    public List<Vehicle> getVehicles() {
        return list;
    }

    public void deleteVehicle(int index) {
        list.remove(index);
    }
}