import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

public class VehicleGUI extends JFrame {

    JTextField vehicleNoField, makeField, modelField, slotField, exitDateField;
    DefaultTableModel tableModel;
    JTable table;

    VehicleManager manager = new VehicleManager();

    // Colour Palette
    static final Color DARK_BLUE  = new Color(25,  50, 100);
    static final Color ACCENT     = new Color(46, 117, 182);
    static final Color LIGHT_BLUE = new Color(214, 228, 248);
    static final Color GREEN      = new Color(0,  153,  76);
    static final Color RED        = new Color(192,   0,   0);
    static final Color ORANGE     = new Color(210, 105,  30);
    static final Color WHITE      = Color.WHITE;
    static final Color FORM_BG    = new Color(240, 245, 255);
    static final Color ROW_ALT    = new Color(232, 240, 255);

    public VehicleGUI() {

        setTitle("Vehicle Parking Management System");
        setSize(1000, 620);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(0, 0));

        // TOP: Title + Form together
        JPanel topPanel = new JPanel(new BorderLayout());

        // Title bar
        JLabel titleLabel = new JLabel("   Vehicle Parking Management System", JLabel.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(WHITE);
        titleLabel.setOpaque(true);
        titleLabel.setBackground(DARK_BLUE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(12, 10, 12, 0));
        topPanel.add(titleLabel, BorderLayout.NORTH);

        // FORM
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(FORM_BG);
        form.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 3, 0, ACCENT),
            BorderFactory.createEmptyBorder(14, 20, 14, 20)
        ));

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5, 8, 5, 8);
        gc.fill   = GridBagConstraints.HORIZONTAL;

        // Row 0 - Labels
        String[] labels  = {"Vehicle No", "Make", "Model", "Slot", "Exit Date (yyyy-MM-dd)"};
        Color[]  lColors = {DARK_BLUE, DARK_BLUE, DARK_BLUE, new Color(0, 120, 0), ORANGE};

        for (int i = 0; i < labels.length; i++) {
            gc.gridx = i; gc.gridy = 0; gc.weightx = 1.0;
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(new Font("Arial", Font.BOLD, 12));
            lbl.setForeground(lColors[i]);
            form.add(lbl, gc);
        }

        // Row 1 - Fields
        vehicleNoField = styledField(ACCENT);
        makeField      = styledField(ACCENT);
        modelField     = styledField(ACCENT);
        slotField      = styledField(GREEN);
        exitDateField  = styledField(ORANGE);

        JTextField[] fields = {vehicleNoField, makeField, modelField, slotField, exitDateField};
        for (int i = 0; i < fields.length; i++) {
            gc.gridx = i; gc.gridy = 1; gc.weightx = 1.0;
            fields[i].setPreferredSize(new Dimension(160, 32));
            form.add(fields[i], gc);
        }

        topPanel.add(form, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        // TABLE
        tableModel = new DefaultTableModel(
            new String[]{"Vehicle No", "Make", "Model", "Slot", "Entry Time", "Exit Date", "Fee (Rs.)"}, 0
        ) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(tableModel) {
            public Component prepareRenderer(javax.swing.table.TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (isRowSelected(row)) {
                    c.setBackground(LIGHT_BLUE);
                    c.setForeground(DARK_BLUE);
                } else {
                    c.setBackground(row % 2 == 0 ? WHITE : ROW_ALT);
                    c.setForeground(Color.DARK_GRAY);
                }
                return c;
            }
        };

        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.setShowGrid(true);
        table.setGridColor(new Color(200, 215, 240));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 13));
        header.setBackground(DARK_BLUE);
        header.setForeground(WHITE);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer centre = new DefaultTableCellRenderer();
        centre.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < tableModel.getColumnCount(); i++)
            table.getColumnModel().getColumn(i).setCellRenderer(centre);

        ((DefaultTableCellRenderer) header.getDefaultRenderer())
            .setHorizontalAlignment(JLabel.CENTER);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        add(scroll, BorderLayout.CENTER);

        // BUTTONS
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 24, 14));
        btnPanel.setBackground(DARK_BLUE);

        JButton addBtn    = styledButton("[ + ]  Entry",  GREEN);
        JButton exitBtn   = styledButton("[ $ ]  Exit",   ORANGE);
        JButton deleteBtn = styledButton("[ X ]  Delete", RED);

        btnPanel.add(addBtn);
        btnPanel.add(exitBtn);
        btnPanel.add(deleteBtn);
        add(btnPanel, BorderLayout.SOUTH);

        // ENTRY ACTION
        addBtn.addActionListener(e -> {
            try {
                String vNo   = vehicleNoField.getText().trim();
                String make  = makeField.getText().trim();
                String model = modelField.getText().trim();
                String slot  = slotField.getText().trim();

                if (vNo.isEmpty() || make.isEmpty() || model.isEmpty() || slot.isEmpty()) {
                    JOptionPane.showMessageDialog(this,
                        "Please fill in all fields!", "Missing Input",
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }

                String entryTime = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
                Vehicle v = new Vehicle(vNo, make, model, slot, entryTime);
                manager.addVehicle(v);
                tableModel.addRow(new Object[]{vNo, make, model, slot, entryTime, "", ""});
                clearFields();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // EXIT ACTION
        exitBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Select a row first!", "No Row Selected",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                String exitDateStr = exitDateField.getText().trim();
                if (exitDateStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Enter exit date!", "Missing Date",
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String entryStr = tableModel.getValueAt(row, 4).toString().split(" ")[0];
                Date entryDate  = sdf.parse(entryStr);
                Date exitDate   = sdf.parse(exitDateStr);

                if (exitDate.before(entryDate)) {
                    JOptionPane.showMessageDialog(this,
                        "Exit date cannot be before entry date!", "Invalid Date",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }

                long diff = exitDate.getTime() - entryDate.getTime();
                long days = (diff / (1000 * 60 * 60 * 24)) + 1;
                double fee = days * 50;

                tableModel.setValueAt(exitDateStr, row, 5);
                tableModel.setValueAt("Rs. " + fee, row, 6);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date! Use yyyy-MM-dd",
                    "Date Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // DELETE ACTION
        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Select a row first!", "No Row Selected",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this record?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                manager.deleteVehicle(row);
                tableModel.removeRow(row);
            }
        });
    }

    // Styled text field
    private JTextField styledField(Color borderColor) {
        JTextField f = new JTextField();
        f.setFont(new Font("Arial", Font.PLAIN, 13));
        f.setForeground(Color.DARK_GRAY);
        f.setBackground(WHITE);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderColor, 2, true),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        return f;
    }

    // Styled button
    private JButton styledButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setForeground(WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(bg.darker(), 1, true),
            BorderFactory.createEmptyBorder(8, 28, 8, 28)
        ));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        Color hover = bg.darker();
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(hover); }
            public void mouseExited(java.awt.event.MouseEvent e)  { btn.setBackground(bg); }
        });
        return btn;
    }

    void clearFields() {
        vehicleNoField.setText("");
        makeField.setText("");
        modelField.setText("");
        slotField.setText("");
        exitDateField.setText("");
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new VehicleGUI().setVisible(true));
    }
}
