public class Vehicle {
    String vehicleNo, make, model, slot;
    String entryTime, exitDate;
    double fee;

    public Vehicle(String vehicleNo, String make, String model, String slot, String entryTime) {
        this.vehicleNo = vehicleNo;
        this.make = make;
        this.model = model;
        this.slot = slot;
        this.entryTime = entryTime;
        this.exitDate = "";
        this.fee = 0;
    }
}